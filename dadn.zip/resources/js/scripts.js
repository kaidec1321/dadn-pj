$(document).ready(
    function(){
        $('h1').click(
            function(){
                $(this).css('color', 'red');
            }
        )
    }
)